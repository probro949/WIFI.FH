package com.fhwifi.app

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.graphics.Color
import android.view.View
import android.webkit.WebSettings

class MainActivity : Activity() {
    private lateinit var webView: WebView

    private val hideFeedbackScript = """
        (function() {
          function hideFeedback() {
            const nodes = Array.from(document.querySelectorAll('body *'));
            for (const el of nodes) {
              if (!el || !el.innerText) continue;
              const text = el.innerText.trim().toLowerCase().replace(/\\s+/g, ' ');
              if (text.includes('is this helpful?') && text.includes('click here')) {
                let target = el;
                while (target.parentElement &&
                       target.parentElement !== document.body &&
                       target.parentElement.innerText &&
                       target.parentElement.innerText.trim().length < 180) {
                  target = target.parentElement;
                }
                target.style.setProperty('display', 'none', 'important');
              }
            }
          }
          hideFeedback();
          const observer = new MutationObserver(hideFeedback);
          observer.observe(document.documentElement, { childList: true, subtree: true });
          setTimeout(hideFeedback, 500);
          setTimeout(hideFeedback, 1500);
        })();
    """.trimIndent()

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5, 12, 28)
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = 0

        webView = WebView(this)
        webView.setBackgroundColor(Color.rgb(5, 12, 28))
        webView.visibility = View.VISIBLE

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.loadsImagesAutomatically = true
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript(hideFeedbackScript, null)
            }
        }
        webView.webChromeClient = WebChromeClient()
        setContentView(webView)

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            webView.loadUrl("https://fh-wlan.vercel.app/")
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android API, retained for compatibility")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
